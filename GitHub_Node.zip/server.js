var github = require("/Users/compagnb/Documents/MFA_DT/2013_Fall/ccLab/week6_hw/github/github.js");
var http = require('http');
console.log("starting");
var host = '127.0.0.1'; // localhost 
var port = 8080;


github.getRepos("compagnb", function(repos){
	console.log("Barb's repos", repos);
});

var server = http.createServer(function(request, response){
	console.log("Recieved request: " + request.url);
	response.writeHead(200, {'Content-type':'text/plain'});
	//response.write('hello world!');
	response.end('hello world!');
});
server.listen(port, host, function(){
	console.log("listening " +host+ " : " +port);
});
