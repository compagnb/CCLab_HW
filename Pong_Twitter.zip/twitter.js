
var twitter = require('ntwitter'); //connect to the twitter module

//twitter authentication

var twit = new twitter({
  		consumer_key: '7auXBBTNTWIYGTedcflqw',
		consumer_secret: 'iPCaLbUBfXi7hxd4g36ac6r6Zu1j575M1S0E6eFamFw',
		access_token_key: '268298268-M1WP6IT57wUH85b6CCyNdt4Iw1V88xSVhV9LB3Dg',
		access_token_secret: 'xthtmBMwoIwIPOtw8R6A2QN8R5OKR1TN85dfP1fzR5U'
});


//create a real-time connection with twitter tracking a phrase
//see all the data for the statuses/filter here:
//https://dev.twitter.com/docs/api/1.1/post/statuses/filter

twit.stream('statuses/filter', {track: 'pong', locations: '-74,40,-73,41'},function(stream){

	//stream on gets called when twitter sends a new event - 
	//in this case something that matches what were tracking

	stream.on('data', function(data){

		//data contains the whole tweet object -
		//print out this whole object (data) to see what it contains

		//console.log(data);

		var tweet_text = data.text;
		var timestamp = data.created_at;
		var username = data.user.screen_name;

		console.log("*****************************");

		console.log("username: "+username);
		console.log("tweet: "+tweet_text);
		console.log("time: "+timestamp);

		console.log("");


	} );

});