//Barbara Compagnoni
//CCLab 

//pong script with the help of an online tutorial to create the first two players... then BAM its an out of control game... kind of like midterms :)
//method tells the browser that you wish to perform an animation and requests that the browser call a specified function to update an animation before the next repain
	var animate = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || function(callback) { window.setTimeout(callback, 1000/60) };

//setup a canvas - setting up canvas variables
	var canvas = document.createElement('canvas');
	var width = 400;
	var height = 600;
	canvas.width = width;
	canvas.height = height;
	var context = canvas.getContext('2d');

//attach the canvas & call step function -  - Very easy new way to attach a canvas without having one set up in the HTML page
	window.onload = function() {
  		document.body.appendChild(canvas);
  		animate(step);
		};

// update and draws paddles and ball
	var step = function() {
  		update();
  		render();
 		animate(step);
	};

	var update = function() {
	};

//background
	var render = function() {
  		context.fillStyle = "#666666";
  		context.fillRect(0, 0, width, height);
	};

//------------CREATING PADDLES AND BALLS------------

//function to create the paddles framework
	function Paddle(x, y, width, height) {
  		this.x = x;
  		this.y = y;
  		this.width = width;
  		this.height = height;
  		this.x_speed = 0;
  		this.y_speed = 0;
	}

//function to render settings for the paddles
	Paddle.prototype.render = function() {
  		context.fillStyle = "white";
  		context.fillRect(this.x, this.y, this.width, this.height);
	};


//function to set the variables for the computer paddle
	function PlayerTop() {
  		this.paddle = new Paddle(175, 10, 50, 10);
	}


//function to set the variables for the player paddle
	function PlayerBottum() {
   		this.paddle = new Paddle(175, 580, 50, 10);
	}

//function to set the variables for the player paddle
	function PlayerLeft() {
   		this.paddle = new Paddle(10, 300, 10, 50);
	}

//function to set the variables for the player paddle
	function PlayerRight() {
   		this.paddle = new Paddle(380, 300, 10, 50);
	}

//function to render the player paddle
	PlayerTop.prototype.render = function() {
  		this.paddle.render();
	};

//function to render the player paddle
	PlayerBottum.prototype.render = function() {
  		this.paddle.render();
	};

//function to render the player paddle
	PlayerLeft.prototype.render = function() {
  		this.paddle.render();
	};

//function to render the player paddle
	PlayerRight.prototype.render = function() {
  		this.paddle.render();
	};


//function to create the ball framework
	function Ball(x, y) {
  		this.x = x;
  		this.y = y;
  		this.x_speed = 0;
  		this.y_speed = 3;
  		this.radius = 5;
	}

//function to render the ball dettings
	Ball.prototype.render = function() {
  		context.beginPath();
  		context.arc(this.x, this.y, this.radius, 2 * Math.PI, false);
  		context.fillStyle = "orange";
  		context.fill();
	};

//creates a new object of each
var PlayerTop = new PlayerTop();
var PlayerBottum = new PlayerBottum();
var PlayerRight = new PlayerRight();
var PlayerLeft = new PlayerLeft();
var ball = new Ball(200, 300);

//renders that object
	var render = function() {
  		context.fillStyle = "666666";
 	 	context.fillRect(0, 0, width, height);
  		PlayerTop.render();
  		PlayerBottum.render();
  		PlayerLeft.render();
  		PlayerRight.render();
  		ball.render();
	};

//----------------ANIMATION-------------------

//updates ball's position on the screen and check paddles positions
	var update = function() {
  		ball.update(PlayerTop.paddle, PlayerBottum.paddle, PlayerLeft.paddle, PlayerRight.paddle);
	};

// increases ball's speed on both x and y and paddle checks for collision
	Ball.prototype.update = function(PlayerTop, PlayerBottum, PlayerLeft, PlayerRight) {
// increases speed
  		this.x += this.x_speed;
 		this.y += this.y_speed;

//Accounting for the radius of the ball
  		var top_x = this.x - ball.radius;
  		var top_y = this.y - ball.radius;
  		var bottom_x = this.x + ball.radius;
  		var bottom_y = this.y + ball.radius;

// off screen reset
		if(this.y < 0 || this.y > canvas.height) { 
    		this.x_speed = 0;
    		this.y_speed = 3;
   			this.x = canvas.width /2;
    		this.y = canvas.height /2;
  		}
  	
  		if(this.x < 0 || this.x > canvas.width) { 
    		this.x_speed = 0;
    		this.y_speed = 3;
    		this.x = canvas.width /2;
    		this.y = canvas.height /2;
  		}

//Paddle Collision
  		if(top_y > canvas.height / 2) {
    		if(top_y < (PlayerBottum.y + PlayerBottum.height) && bottom_y > PlayerBottum.y && top_x < (PlayerBottum.x + PlayerBottum.width) && bottom_x > PlayerBottum.x) {
// hit the bottom paddle
      			this.y_speed = -3;
      			this.x_speed += (PlayerBottum.x_speed / 2);
      			this.y += this.y_speed;
      		}
  		} if(top_y < canvas.height / 2){
    			if(top_y < (PlayerTop.y + PlayerTop.height) && bottom_y > PlayerTop.y && top_x < (PlayerTop.x + PlayerTop.width) && bottom_x > PlayerTop.x) {
// hit the Top paddle
      					this.y_speed = 3;
     					this.x_speed += (PlayerTop.x_speed / 2);
     					this.y += this.y_speed;
    				}
  				}

  		if(top_x > canvas.width /2) {
    		if(top_x < (PlayerRight.x + PlayerRight.width) && bottom_x > PlayerRight.x && top_y < (PlayerRight.y + PlayerRight.height) && bottom_y > PlayerRight.y) {
// hit the right paddle
      			this.x_speed = -3;
      			this.y_speed += (PlayerRight.y_speed / 2);
      			this.x += this.x_speed;
      		}
  		} if(top_x < canvas.width /2){
    			if(top_x < (PlayerLeft.x + PlayerLeft.width) && bottom_x > PlayerLeft.x && top_y < (PlayerLeft.y + PlayerLeft.height) && bottom_y > PlayerLeft.y) {
// hit the left paddle
      					this.x_speed = 3;
     					this.y_speed += (PlayerLeft.y_speed / 2);
     					this.x += this.x_speed;
    				}
  				}
		};

//Keys turn on and off... allows you to hold down multiple keys at the same time
	var keysDown = {};

	window.addEventListener("keydown", function(event) {
  		keysDown[event.keyCode] = true;
	});

	window.addEventListener("keyup", function(event) {
  		delete keysDown[event.keyCode];
	});

  var update = function() {
      PlayerBottum.update();
      PlayerTop.update();
      PlayerLeft.update();
      PlayerRight.update();
      ball.update(PlayerBottum.paddle, PlayerTop.paddle, PlayerLeft.paddle, PlayerRight.paddle);
  };

	PlayerBottum.update = function() {
  		for(var key in keysDown) {
    		var value = Number(key);
    		if(value == 37) { // left arrow
      			this.paddle.move(-4, 0);
    		} else if (value == 39) { // right arrow
      			this.paddle.move(4, 0);
   			} else {
      			this.paddle.move(0, 0);
    		}
 		 }
	};

	PlayerBottum.paddle.move = function(x, y) {
  		this.x += x;
  		this.y += y;
  		this.x_speed = x;
  		this.y_speed = y;
  		
  		if(this.x < 0) { // all the way to the left
    		this.x = 0;
    		this.x_speed = 0;
  		} else if (this.x + this.width > canvas.width) { // all the way to the right
    		this.x = canvas.width - this.width;
    		this.x_speed = 0;
  		}
	}

	PlayerTop.update = function() {
  		for(var key in keysDown) {
    		var value = Number(key);
    		if(value == 65) { // A key
      			this.paddle.move(-4, 0);
    		} else if (value == 68) { // D Key
      			this.paddle.move(4, 0);
    		} else {
      			this.paddle.move(0, 0);
    		}
  		}
	};

	Paddle.prototype.move = function(x, y) {
  		this.x += x;
  		this.y += y;
  		this.x_speed = x;
  		this.y_speed = y;
  	
  		if(this.x < 0) { // all the way to the left
    		this.x = 0;
    		this.x_speed = 0;
  		} else if (this.x + this.width > canvas.width) { // all the way to the right
    		this.x = canvas.width - this.width;
    		this.x_speed = 0;
  		}
	}


	PlayerLeft.update = function() {
  		for(var key in keysDown) {
    		var value = Number(key);
    		if(value == 87) { // W key
      			this.paddle.move(0, -4);
    		} else if (value == 83) { // S Key
      			this.paddle.move(0, 4);
    		} else {
      			this.paddle.move(0, 0);
    		}
  		}
	};

	Paddle.prototype.move = function(x, y) {
  		this.x += x;
  		this.y += y;
  		this.x_speed = x;
  		this.y_speed = y;
  	
  		if(this.y < 0) { // all the way to the left
    		this.y = 0;
    		this.y_speed = 0;
  		} else if (this.y + this.height > canvas.height) { // all the way to the top
    		this.y = canvas.height - this.width;
    		this.y_speed = 0;
  		}
	}


	PlayerRight.update = function() {
  		for(var key in keysDown) {
    		var value = Number(key);
    		if(value == 38) { // Arrow up key
      			this.paddle.move(0, -4);
    		} else if (value == 40) { // Arrow downKey
      			this.paddle.move(0, 4);
    		} else {
      			this.paddle.move(0, 0);
    		}
  		}
	};

	Paddle.prototype.move = function(x, y) {
  		this.x += x;
  		this.y += y;
  		this.x_speed = x;
  		this.y_speed = y;
  	
  		if(this.y < 0) { // all the way to the left
    		this.y = 0;
    		this.y_speed = 0;
  		} else if (this.y + this.height > canvas.height) { // all the way to the top
    		this.y = canvas.height - this.width;
    		this.y_speed = 0;
  		}
	}


